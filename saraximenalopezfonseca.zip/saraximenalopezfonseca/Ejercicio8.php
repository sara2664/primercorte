<head> 
  <title>Problema</title> 
</head> 
<body> 
  <?php 
  $cadena1 = "primer"; 
  $cadena2 = "segundo"; 
  $cadena3 = "tercero"; 
  $cadena4 = "El evento tuvo ";
  $num1 = 120;
  $num2 = 150;
  $num3 = 180;
 echo $cadena4 . "$num1 asistentes el $cadena1 dia ,";
 echo $num2 . "  el $cadena2 y ";
 echo $num3 . " el $cadena3.";
 echo "<br>"
  ?> 
</body> 
</html> 