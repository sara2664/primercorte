<head> 
  <title>Problema</title> 
</head> 
<body> 
  <?php 
  $cadena4 = "Los empleados tienen 5, 8 y 3 años de experiencia respectivamente.  ";
  $num1 = 5;
  $num2 = 8;
  $num3 = 3;
 echo $cadena4 ;
  ?> 
</body> 
</html> 