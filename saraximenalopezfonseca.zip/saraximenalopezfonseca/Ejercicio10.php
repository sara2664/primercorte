<head> 
  <title>Problema</title> 
</head> 
<body> 
  <?php 
  $cadena1 = "El estudiante obtuvo las siguientes puntuaciones";
  $num1 = 85;
  $num2 = 90;
  $num3 = 78;
 echo $cadena1 . " $num1, ";
 echo $num2 . " y ";
 echo $num3 .
 "<br>"
  ?> 
</body> 
</html> 