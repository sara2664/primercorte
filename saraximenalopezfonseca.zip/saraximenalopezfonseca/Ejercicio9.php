<head> 
  <title>Problema</title> 
</head> 
<body> 
  <?php 
  $cadena1 = "mañana"; 
  $cadena2 = "tarde"; 
  $cadena3 = "noche"; 
  $cadena4 = "En el restaurante se atendieron";
  $num1 = 30;
  $num2 = 45;
  $num3 = 60;
 echo $cadena4 . " $num1 clientes en la $cadena1, ";
 echo $num2 . " en la $cadena2 y ";
 echo $num3 . " en la $cadena3.";
 echo "<br>"
  ?> 
</body> 
</html> 