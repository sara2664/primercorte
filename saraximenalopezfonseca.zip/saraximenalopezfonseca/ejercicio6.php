<head> 
  <title>Problema</title> 
</head> 
<body> 
  <?php 
  $cadena1 = "febrero"; 
  $cadena2 = "marzo"; 
  $cadena3 = "en enero se leyeron 3 libros,  ";
  $num1 = 5;
  $num2 = 2;
 echo $cadena3 . "$cadena1 $num1,";
 echo $cadena2 . " $num2 ,";
 echo "<br>"
  ?> 
</body> 
</html> 