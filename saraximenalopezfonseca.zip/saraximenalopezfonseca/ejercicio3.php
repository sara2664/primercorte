<html> 
 
<head> 
  <title>Problema</title> 
</head> 
<body> 
  <?php 
  $cadena1 = "partido 1"; 
  $cadena2 = "partido 2"; 
  $cadena3 = "partido 3"; 
  $todo = $cadena1 . $cadena2 . $cadena3 . "<br>"; 
  echo $todo;
  $num1 = 2;
echo "<br>";
  $todo = $cadena1 . $cadena2 . $cadena3 . "<br>";
  echo $cadena1 . " tiene $num1 de goles"; 
  $num2 = 3;
echo "<br>";
  $todo = $cadena1 . $cadena2 . $cadena3 . "<br>"; 
  echo $cadena2 . " tiene $num2 de goles";
  $num3 =1;
echo "<br>";
  $todo = $cadena1 . $cadena2 . $cadena3 . "<br>";  
  echo $cadena3 . " tiene $num3 de gol";
  ?> 
</body> 
</html> 
 
