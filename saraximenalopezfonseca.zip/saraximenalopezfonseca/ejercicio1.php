<html> 
 
<head> 
  <title>Problema</title> 
</head> 
<body> 
  <?php 
  $cadena1 = "sara"; 
  $cadena2 = "andres"; 
  $cadena3 = "juan"; 
  $todo = $cadena1 . $cadena2 . $cadena3 . "<br>"; 
  echo $todo; 
  $edad1 = 17; 
  echo $cadena1 . " tiene $edad1 de edad";
 $todo = $cadena1 . $cadena2 . $cadena3 . "<br>"; 
  echo $todo;
$edad2 = 17;
echo $cadena2 . " tiene $edad2 de edad";
 $todo = $cadena1 . $cadena2 . $cadena3 . "<br>"; 
  echo $todo; 
  $edad3 = 20; 
  echo $cadena3 . " tiene $edad3 de edad";

   
 ?>
</body> 
</html>