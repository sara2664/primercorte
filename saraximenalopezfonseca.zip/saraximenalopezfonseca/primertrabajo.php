<html>

<head></head>

<body>

<?php

echo"Bienvenido a clase de programacion";

echo "<br>";

echo "Mi nombre es Sara Lopez";

echo "<br>";

echo "Tengo 16, pero en 2 dias tendre 17";

echo "<br>";

echo "Estudio Ingenieria Industrial en la Universidad Sergio Arboleda";

echo "<br>";

echo "Mis gustos musicales son muy variados, escucho de todo un poco";

echo "<br>";

echo "Me gusta mucho la comida de sal, sinceramente la prefiero mucho mas que la comida dulce, principalmente me encanta la lasaña; entre otras cosas, me gusta mucho ver series o peliculas que cuentan historias de siglos pasados";

echo "<br>";

echo "Mi viaje soñado es ir a Europa, me encanta sus cultura y diseño, aunque principalmente quisiera ir a Inglatera";

echo "<br>";

echo "Todos los diciembres voy donde mis abuelos en Boyaca";

echo "<br>";

echo "Mi lugar favorito es mi casa, amo estar alli y no salir";

echo "<br>";

echo "Vivo en la parte norte de Bogota";

echo "<br>";

echo "Me encanta el maquillaje";

echo "<br>";

echo "Amo salir a comprar ropa o a comer";

echo "<br>";

echo "No tengo mascotas";

echo "<br>";

echo "Mi aplicacion favorita es Tiktok";

echo "<br>";

echo "No me gusta tener que elegir";

echo "<br>";

echo "No me gusta la papaya";

echo "<br>";

echo "Tampoco me gusta el pescado";

echo "<br>";

echo "No me gusta el color rojo o fucsia en la ropa";

echo "<br>";

echo "Vivo con mis padres y mi hermano";

echo "<br>";

echo "Se me hace muy dificil la programacion";

echo "<br>";

echo "Necesito gafas";

?>

</body>

</html>