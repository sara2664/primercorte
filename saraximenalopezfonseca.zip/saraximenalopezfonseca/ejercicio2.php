<html> 
 
<head> 
  <title>Problema</title> 
</head> 
<body> 
  <?php 
  $cadena1 = "lunes"; 
  $cadena2 = "martes"; 
  $cadena3 = "miercoles"; 
  $todo = $cadena1 . $cadena2 . $cadena3 . "<br>"; 
  echo $todo; 
  $precio1 =15; 
echo "<br>";
  echo $cadena1 . " tiene $precio1 de venta"; 
 $todo = $cadena1 . $cadena2 . $cadena3 . "<br>";
echo "<br>";   
$precio2 =20; 
  echo $cadena2 . " tiene $precio2 de venta"; 
"<br>";
 $todo = $cadena1 . $cadena2 . $cadena3 . "<br>"; 
echo "<br>";
  $precio3 =18;
  echo $cadena3 . " tiene $precio3 de venta"; 
?> 
</body> 
</html> 
 
 
