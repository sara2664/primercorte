<head> 
  <title>Problema</title> 
</head> 
<body> 
  <?php 
  $cadena1 = "dia 1"; 
  $cadena2 = "dia 2"; 
  $cadena3 = "dia 3"; 
  $cadena4 = "las temperaturas registradas fueron: ";
  $todo = $cadena1 . $cadena2 . $cadena3 . "<br>"; 
  echo $todo;
  $num1 = 22;
  $num2 = 25;
  $num3 =20;
 echo $cadena4 . "$cadena1:$num1 °c,";
 echo $cadena2 . ": $num2 °c,";
 echo $cadena3 . ": $num3 °c,";
 echo "<br>"
  ?> 
</body> 
</html> 
 