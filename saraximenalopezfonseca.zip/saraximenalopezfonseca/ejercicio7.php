<head> 
  <title>Problema</title> 
</head> 
<body> 
  <?php 
  $cadena1 = "primer dia"; 
  $cadena2 = "segundo"; 
  $cadena3 = "tercero"; 
  $cadena4 = "el ciclista recorrio el ";
  $num1 = 15;
  $num2 = 20;
  $num3 = 12;
 echo $cadena4 . "$cadena1 $num1 km,";
 echo $num2 . " km el $cadena2, ";
 echo $num3 . " km el $cadena3.";
 echo "<br>"
  ?> 
</body> 
</html> 