<html>

<head></head>

<body>

<?php

echo"Hoja de Vida";

echo "<br>";

echo "Nombre: Sara Ximena Lopez Fonseca";

echo "<br>";

echo "Edad: 17";

echo "<br>";

echo "Fecha de Nacimiento: 26/02/2008";

echo "<br>";

echo "Coontacto: 1234567891";

echo "<br>";

echo "Correo electronico: sara.lopez03@usa.edu.co";

echo "<br>";

echo "Residencia: Bogota";

echo "<br>";

echo "Experiencia: Ninguna";

echo "<br>";

echo "Perfil Profesional: Habilidades de escucha, comunicacion, pensamiento critico ";

echo "<br>";

echo "Titulo Obtenido: Bachiller Academico";

echo "<br>";

echo "Habilidades Tecnicas: Excel Avanzado, Analisis Financiero";

echo "<br>";

echo "Habilidades blandas: Liderazgo, trabajo en equipo";

echo "<br>";

echo "Intereses: Finanzas personales";

echo "<br>";

echo "Disonibilidad para viajar o cambiar de residencia";

echo "<br>";

echo "Alergias: Ninguna";

echo "<br>";

echo "EPS: Compensar";

echo "<br>";

echo "Mascotas: Ninguna";

echo "<br>";

echo "Enfermedades: Ninguna";

echo "<br>";

echo "Recomendaciones: Danna Gonzalez";

echo "<br>";

echo "Contacto: 9876543219";

echo "<br>";

echo "Estudios profesionales: Cursando ingenieria Industrial";

?>

</body>

</html>